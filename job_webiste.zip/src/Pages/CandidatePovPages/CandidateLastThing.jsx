import React from 'react'
import LastThing from '../../components/CandidatePov/OneLastThing/LastThing'

const CandidateLastThing = () => {
  return (
    <div>
      <LastThing />
    </div>
  )
}

export default CandidateLastThing
