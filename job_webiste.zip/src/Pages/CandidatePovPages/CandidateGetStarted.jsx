import React from 'react'
import PlutoGet from '../../components/CandidatePov/PlutoGetStarted/PlutoGet'

const CandidateGetStarted = () => {
  return (
    <div>
      <PlutoGet />
    </div>
  )
}

export default CandidateGetStarted
