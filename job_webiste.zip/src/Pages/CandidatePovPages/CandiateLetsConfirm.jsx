import React from 'react'
import LetConfirm from '../../components/CandidatePov/LetsConfirmit/LetConfirm'

const CandiateLetsConfirm = () => {
  return (
    <div>
      <LetConfirm />
    </div>
  )
}

export default CandiateLetsConfirm
