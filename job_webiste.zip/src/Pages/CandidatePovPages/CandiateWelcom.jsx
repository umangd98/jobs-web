import React from 'react'
import WelcomePluto from '../../components/CandidatePov/WelcomeToPluto/WelcomePluto'

const CandiateWelcom = () => {
  return (
    <div>
      <WelcomePluto />
    </div>
  )
}

export default CandiateWelcom
