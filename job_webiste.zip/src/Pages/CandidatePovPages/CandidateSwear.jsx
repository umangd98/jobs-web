import React from 'react'
import Swear from '../../components/CandidatePov/Iswear/Swear'

const CandidateSwear = () => {
  return (
    <div>
      <Swear />
    </div>
  )
}

export default CandidateSwear
