import React from 'react'
import LookRight from '../../components/CandidatePov/DoThisLookRight/LookRight'

const CandidateLookRight = () => {
  return (
    <div>
      <LookRight />
    </div>
  )
}

export default CandidateLookRight
