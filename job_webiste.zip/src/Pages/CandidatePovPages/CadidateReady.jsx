import React from 'react'
import Ready from '../../components/CandidatePov/Ready/Ready'

const CadidateReady = () => {
  return (
    <div>
      <Ready />
    </div>
  )
}

export default CadidateReady
