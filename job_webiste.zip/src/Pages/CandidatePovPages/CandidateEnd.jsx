import React from 'react'
import End from '../../components/CandidatePov/CandidateEnd/End'

const CandidateEnd = () => {
  return (
    <div>
      <End />
    </div>
  )
}

export default CandidateEnd
