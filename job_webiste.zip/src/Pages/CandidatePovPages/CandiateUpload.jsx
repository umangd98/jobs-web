import React from 'react'
import UploadFile from '../../components/CandidatePov/ClicktoUpload/UploadFile'

const CandiateUpload = () => {
  return (
    <div>
      <UploadFile />
    </div>
  )
}

export default CandiateUpload
