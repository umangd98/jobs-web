import React from 'react'
import JustLittle from '../../components/CandidatePov/JustLittleBite/JustLittle'

const CandidateJustLittle = () => {
  return (
    <div>
      <JustLittle />
    </div>
  )
}

export default CandidateJustLittle
