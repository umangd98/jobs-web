import React from 'react'
import SignInJobListingsTwo from '../../components/SignIn/JobListingTwo/SignInJobListingsTwo'

const SingJobListTwo = () => {
  return (
    <div>
      <SignInJobListingsTwo />
    </div>
  )
}

export default SingJobListTwo
