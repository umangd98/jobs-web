import React from 'react'
import SeniorDeveloper from '../../components/SignIn/SenioProductDeveloper/SeniorDeveloper'

const SignSeniorDev = () => {
  return (
    <div>
      <SeniorDeveloper />
    </div>
  )
}

export default SignSeniorDev
