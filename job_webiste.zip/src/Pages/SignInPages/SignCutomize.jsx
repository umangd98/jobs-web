import React from 'react'
import SignCutomizeOne from '../../components/SignIn/SignCustomize/SignCutomizeOne'

const SignCutomize = () => {
  return (
    <div>
      <SignCutomizeOne />
    </div>
  )
}

export default SignCutomize
