import React from 'react';
import SignJobDetails from '../../components/SignIn/JobDetails/SignJobDetails';


const SignInJobDet = () => {
  return (
    <div>
      <SignJobDetails />
    </div>
  )
}

export default SignInJobDet
