import LandingPage from "../../components/FirmPov/LandingPageCom/LandingPage";

const Landing = () => {
  return <LandingPage />;
};

export default Landing;
