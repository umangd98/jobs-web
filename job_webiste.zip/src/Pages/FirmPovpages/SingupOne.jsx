import React from 'react'
import EnterprisePlan from '../../components/FirmPov/SingupOne/EnterprisePlan'

const SingupOne = () => {
  return (
    <div>
    <EnterprisePlan />
    </div>
  )
}

export default SingupOne
