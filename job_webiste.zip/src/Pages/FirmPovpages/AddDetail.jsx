import React from 'react'
import JobDetails from '../../components/FirmPov/JobDetails/JobDetails'

const AddDetail = () => {
  return (
    <div>
      <JobDetails />
    </div>
  )
}

export default AddDetail
