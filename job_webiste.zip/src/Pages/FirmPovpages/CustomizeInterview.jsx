import React from 'react'
import JobTwo from '../../components/FirmPov/CustomizeInterview/JobTwo'

const CustomizeInterview = () => {
  return (
    <div>
      <JobTwo />
    </div>
  )
}

export default CustomizeInterview
