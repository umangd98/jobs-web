import React from 'react'
import SeniorProductDeveloper from '../../components/FirmPov/SeniorProduct/SeniorProductDeveloper'

const SeniorProduct = () => {
  return (
    <div>
      <SeniorProductDeveloper />
    </div>
  )
}

export default SeniorProduct
