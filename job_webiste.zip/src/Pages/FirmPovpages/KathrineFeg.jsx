import React from 'react'
import KatherineFag from '../../components/FirmPov/KatherineFeg/KatherineFag'

const KathrineFeg = () => {
  return (
    <div>
      <KatherineFag />
    </div>
  )
}

export default KathrineFeg
