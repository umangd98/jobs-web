import React from 'react'
import JobListings from '../../components/FirmPov/JobListing/JobListings'

const AddJob = () => {
  return (
    <div>
      <JobListings />
    </div>
  )
}

export default AddJob
