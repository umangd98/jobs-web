import React from 'react'
import DiveDeeper from '../../components/FirmPov/SingupTwo/DiveDeeper'

const SingupTwo = () => {
  return (
    <div>
      <DiveDeeper />
    </div>
  )
}

export default SingupTwo
