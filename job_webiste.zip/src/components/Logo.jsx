
const Logo = () => {
  return (
    <div>
        <div className="">
        <img src="/logo.png" alt="logo" className="w-[300px] h-[90px] object-cover " />
      </div>
    </div>
  )
}

export default Logo
